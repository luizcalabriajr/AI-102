from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest
from utils.Config import Config

def  analyze_credit_card(card_url):
    
    credential = AzureKeyCredential(Config.KEY)

    document_client = DocumentIntelligenceClient(Config.ENDPOINT, credential)

    card_info = document_client.begin_analyze_document(
        "prebuilt-creditcard", AnalyzeDocumentRequest(url_source=card_url))
    result = card_info.result()
      
    for document in result.documents:
         fields = document.get('fields',{})

         return{
             "card_name": fields.get('CardHolderName', {}).et('content'),
             "card_number": fields.get('CardNumber', {}).et('content'),
             "expiry_date": fields.get('ExpirationDate', {}).et('content'),
             "bank_name": fields.get('IssuingBank', {}).et('content'),
         }

